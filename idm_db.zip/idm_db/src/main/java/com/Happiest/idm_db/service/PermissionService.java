package com.Happiest.idm_db.service;



import com.Happiest.idm_db.entities.Permission;

import java.util.List;

public interface PermissionService {

    public List<Permission> findAll();

    public List<Permission> findByFeature(String theFeature);


}
