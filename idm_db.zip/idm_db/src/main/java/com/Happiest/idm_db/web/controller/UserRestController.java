package com.Happiest.idm_db.web.controller;

import com.Happiest.idm_db.entities.User;
import com.Happiest.idm_db.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api")
 class UserRestController 
{
	
private UserService userService;
	
	@Autowired
	public UserRestController(UserService theUserService)
	{
		userService =  theUserService;
	}
    
	@GetMapping("/users/list")
	public List<User> findAllUsers()
	{
		return userService.findAll();
	}
}
