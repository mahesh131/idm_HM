package com.Happiest.idm_db.web.controller;

import com.Happiest.idm_db.entities.Role;
import com.Happiest.idm_db.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api")
public class RoleRestController {
	private RoleService roleService;

	@Autowired
	public RoleRestController(RoleService theRoleService) {
		roleService = theRoleService;
	}

	@GetMapping("/roles")
	public List<Role> findAllRoles() {
		return roleService.findAll();
	}

	@PostMapping("/roles")
	public Role addRoles(@RequestBody Role theRole) {
		roleService.save(theRole);
		return theRole;
	}

	@GetMapping("/roles/{roleId}")
	public Role getRole(@PathVariable Long roleId) {
		Role theRole = roleService.findById(roleId);
		if (theRole == null) {
			throw new RuntimeException("Role id not found " + roleId);
		}
		return theRole;
	}


	@DeleteMapping("/roles/{roleId}")
	public String deleteById(@PathVariable Long roleId) {
		Role tempRole = roleService.findById(roleId);

		if (tempRole == null) {
			throw new RuntimeException("Role id not found " + roleId);
		} else {
			roleService.deleteById(roleId);
			return "Role deleted successfully " + roleId;
		}
	}
	@PutMapping("/roles")
	public Role updateRole(@RequestBody Role theRole)
	{
		roleService.save(theRole);
		return theRole;

	}


}