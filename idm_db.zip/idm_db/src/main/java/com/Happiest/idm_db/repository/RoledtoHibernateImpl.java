package com.Happiest.idm_db.repository;

import com.Happiest.idm_db.dto.Roledto;
import com.Happiest.idm_db.entities.Role;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;


@Repository
public class RoledtoHibernateImpl implements Roledto {
	
	  //define field for entityManager
    private EntityManager entityManager;

    @Autowired
    public RoledtoHibernateImpl (EntityManager theEntityManager){
        entityManager =  theEntityManager;
    }

	@Override
	public List<Role> findAll()
	{
        //get the current hibernate session
        Session currentSession =  entityManager.unwrap(Session.class);

        //create a query
        Query<Role> theQuery = currentSession.createQuery("from Role",Role.class);

        //execute query and get result list
        List<Role> roles = theQuery.getResultList();

        //return the results
        return roles;
	}

	@Override
	public void save(Role theRole)
	 {
		 Session currentSession =  entityManager.unwrap(Session.class);
		 currentSession.saveOrUpdate(theRole);
	}

	@Override
	public Role findById(Long roleId)
	{
		//get the current hibernate session
		Session currentSession =  entityManager.unwrap(Session.class);

		//create a query
		Role theRole  = currentSession.get(Role.class, roleId);

		return theRole;
	}

	@Override
	public void deleteById(Long theId)
	{
		//get the current hibernate session
		Session currentSession =  entityManager.unwrap(Session.class);

		//create a query
		Query<Role> theQuery = currentSession.createQuery("delete from Role where id=:roleId");

		theQuery.setParameter("roleId", theId);

		theQuery.executeUpdate();
	}

}
