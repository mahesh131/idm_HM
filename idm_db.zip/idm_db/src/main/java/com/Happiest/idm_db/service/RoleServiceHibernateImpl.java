package com.Happiest.idm_db.service;

import java.util.List;

import com.Happiest.idm_db.entities.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Happiest.idm_db.repository.RoledtoHibernateImpl;

import javax.transaction.Transactional;


@Service
public class RoleServiceHibernateImpl implements RoleService {
	
	
	private RoledtoHibernateImpl roleDtoHibernateimpl;
	
	@Autowired
	public RoleServiceHibernateImpl(RoledtoHibernateImpl theRoleDtoHibernateimpl)
	{
		roleDtoHibernateimpl = 	theRoleDtoHibernateimpl;
	}
	

	@Override
	@Transactional
	public List<Role> findAll()
	{
		return  roleDtoHibernateimpl.findAll();
	}


	@Override
	@Transactional
	public void save(Role theRole) 
	{
		roleDtoHibernateimpl.save(theRole);
		
	}

	@Override
	@Transactional
	public Role findById(Long roleId)
	{
		return roleDtoHibernateimpl.findById(roleId);
	}


	@Override
	@Transactional
	public void deleteById(Long theId)
	{
		roleDtoHibernateimpl.deleteById(theId);

	}



}
