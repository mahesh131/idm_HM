package com.Happiest.idm_db.service;

import com.Happiest.idm_db.entities.PasswordPolicy;

import java.util.List;



public interface PasswordPolicyService 
{
  
	public List<PasswordPolicy> findAll();
}
