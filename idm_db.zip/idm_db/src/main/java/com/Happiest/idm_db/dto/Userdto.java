package com.Happiest.idm_db.dto;

import com.Happiest.idm_db.entities.User;

import java.util.List;



public interface Userdto 
{
	public List<User> findAll();

}
