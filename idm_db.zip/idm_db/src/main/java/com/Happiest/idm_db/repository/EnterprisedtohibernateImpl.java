package com.Happiest.idm_db.repository;
import com.Happiest.idm_db.dto.Enterprisedto;
import com.Happiest.idm_db.entities.Enterprise;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;


@Repository
public class EnterprisedtohibernateImpl implements Enterprisedto
{
     private EntityManager entityManager;
     
     @Autowired
     public EnterprisedtohibernateImpl( EntityManager theEntityManager) {
    	 
    	 entityManager = theEntityManager;
    	 
     }

	@Override
	public List<Enterprise> findAll()
	{
	Session currentSession = entityManager.unwrap(Session.class);
	
	Query<Enterprise> theQuery =  currentSession.createQuery("from Enterprise",Enterprise.class);
	
	List<Enterprise> allEnterprises = theQuery.getResultList();
	
	return allEnterprises ;
		
	}



	@Override
	public Enterprise findByEnterpriseCode(String theEnterpriseCode)
	{
		Session currentSession = entityManager.unwrap(Session.class);
		
		Enterprise   theEnterprise =  currentSession.get(Enterprise.class, theEnterpriseCode );
	
		return theEnterprise ;
	}

}
