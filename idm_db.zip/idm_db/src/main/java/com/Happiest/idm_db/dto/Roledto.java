package com.Happiest.idm_db.dto;

import com.Happiest.idm_db.entities.Role;

import java.util.List;



public interface Roledto
{
	 public List<Role> findAll();
	 
	 public void save(Role theRole);

	public Role findById(Long roleId);

	public void deleteById(Long theId);
}
