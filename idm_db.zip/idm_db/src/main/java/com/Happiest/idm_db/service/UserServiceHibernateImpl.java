package com.Happiest.idm_db.service;

import java.util.List;

import javax.transaction.Transactional;

import com.Happiest.idm_db.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Happiest.idm_db.repository.UserdtohibernateImpl;


@Service
public class UserServiceHibernateImpl implements UserService 
{
	private UserdtohibernateImpl userdtoHibernateImpl;
	
	@Autowired
	public UserServiceHibernateImpl(UserdtohibernateImpl theUserdtohibernateImpl)
	{
		userdtoHibernateImpl = 	theUserdtohibernateImpl;
	}

	@Override
	@Transactional
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return  userdtoHibernateImpl.findAll();
	}

}
