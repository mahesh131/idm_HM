package com.Happiest.idm_db.service;

import java.util.List;

import javax.transaction.Transactional;

import com.Happiest.idm_db.entities.Enterprise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Happiest.idm_db.repository.EnterprisedtohibernateImpl;


@Service
public class EnterpriseServiceHibernateImpl implements EnterpriseService {
	
	private EnterprisedtohibernateImpl enterprisedtoHibernateImpl;
	
	@Autowired
	public EnterpriseServiceHibernateImpl(EnterprisedtohibernateImpl theEnterprisedtoHibernateImpl) {
		 enterprisedtoHibernateImpl = theEnterprisedtoHibernateImpl;
	}

	@Override
	@Transactional
	public List<Enterprise> findAll() {
		return  enterprisedtoHibernateImpl.findAll();
	}

	@Override
	@Transactional
	public Enterprise findByEnterpriseCode(String theEnterpriseCode) {
		
		return enterprisedtoHibernateImpl.findByEnterpriseCode(theEnterpriseCode);
	}

}
