package com.HM.idm_db.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "ENTERPRISE")
public class Enterprise extends BaseId implements Serializable {
    @Column(name = "NAME")
    private String name;
    @Column(name = "STATUS")
    private Character status;
    @Column(name = "ENTERPRISE_CODE")
    private String code;
    @Column(name = "ENTERPRISE_TYPE")
    private String type;
    
    public Enterprise(){}



    public Enterprise(String name, Character status, String code, String type) {
		super();
		this.name = name;
		this.status = status;
		this.code = code;
		this.type = type;
	}



	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }



	@Override
	public String toString() {
		return "Enterprise [name=" + name + ", status=" + status + ", code=" + code + ", type=" + type + "]";
	}
    
}
