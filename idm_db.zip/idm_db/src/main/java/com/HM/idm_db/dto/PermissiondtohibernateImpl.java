package com.HM.idm_db.dto;


import com.HM.idm_db.entities.Permission;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
public class PermissiondtohibernateImpl implements Permissiondto {

    //define field for entityManager
    private EntityManager entityManager;

    @Autowired
    public PermissiondtohibernateImpl (EntityManager theEntityManager){
        entityManager =  theEntityManager;
    }


    @Override
    public List<Permission> findAll() {
        //get the current hibernate session
        Session currentSession =  entityManager.unwrap(Session.class);

        //create a query
        Query<Permission> theQuery = currentSession.createQuery("from Permission",Permission.class);

        //execute query and get result list
        List<Permission> permissions = theQuery.getResultList();

        //return the results
        return permissions;


        }

    @Override
    public Permission findByFeature(int feature) {
        return null;
    }
}
