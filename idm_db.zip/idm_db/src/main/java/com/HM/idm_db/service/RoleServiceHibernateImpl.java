package com.HM.idm_db.service;

import java.util.List;

import com.HM.idm_db.dto.RoledtoHibernateImpl;
import com.HM.idm_db.entities.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class RoleServiceHibernateImpl implements RoleService {
	
	
	private RoledtoHibernateImpl roleDtoHibernateimpl;
	
	@Autowired
	public RoleServiceHibernateImpl(RoledtoHibernateImpl theRoleDtoHibernateimpl)
	{
		roleDtoHibernateimpl = 	theRoleDtoHibernateimpl;
	}
	

	@Override
	public List<Role> findAll()
	{
		return  roleDtoHibernateimpl.findAll();
	}

}
