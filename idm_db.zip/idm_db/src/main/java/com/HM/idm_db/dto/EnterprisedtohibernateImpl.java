package com.HM.idm_db.dto;

import java.util.List;

import javax.persistence.EntityManager;

import com.HM.idm_db.entities.Enterprise;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class EnterprisedtohibernateImpl implements Enterprisedto
{
     private EntityManager entityManager;
     
     @Autowired
     public EnterprisedtohibernateImpl( EntityManager theEntityManager) {
    	 
    	 entityManager = theEntityManager;
    	 
     }
	
	
	
	@Override
	public List<Enterprise> findAll()
	{
	Session currentSession = entityManager.unwrap(Session.class);
	
	Query<Enterprise> theQuery =  currentSession.createQuery("from Enterprise",Enterprise.class);
	
	   List<Enterprise> allEnterprises = theQuery.getResultList();
	
	return allEnterprises ;
		
	}


		
		
		
	}


