package com.HM.idm_db.controller;

import java.util.List;

import com.HM.idm_db.entities.User;
import com.HM.idm_db.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api")
public class UserRestController 
{

	private UserService userService;
	
	@Autowired
	public UserRestController(UserService theUserService)
	{
		userService =  theUserService;
	}
    
	@GetMapping("/users/list")
	public List<User> findAllRoles()
	{
		return userService.findAll();

}
}