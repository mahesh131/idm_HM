package com.HM.idm_db.service;



import com.HM.idm_db.dto.PermissiondtohibernateImpl;
import com.HM.idm_db.entities.Permission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class PermissionServicehibernateImpl implements PermissionService {

    private PermissiondtohibernateImpl permissiondto;

    @Autowired
    public PermissionServicehibernateImpl(PermissiondtohibernateImpl thePermissiondto)
    {
        permissiondto = thePermissiondto;
    }

    @Override
    @Transactional
    public List<Permission> findAll() {
        return permissiondto.findAll();
    }

    @Override
    @Transactional
    public Permission findByFeature(int feature) {
        return null;
    }


}
