package com.HM.idm_db.dto;

import java.util.List;

import javax.persistence.EntityManager;

import com.HM.idm_db.entities.Role;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class RoledtoHibernateImpl implements Roledto {
	
	  //define field for entityManager
    private EntityManager entityManager;

    @Autowired
    public RoledtoHibernateImpl (EntityManager theEntityManager){
        entityManager =  theEntityManager;
    }

	@Override
	public List<Role> findAll()
	{
        //get the current hibernate session
        Session currentSession =  entityManager.unwrap(Session.class);

        //create a query
        Query<Role> theQuery = currentSession.createQuery("from Role",Role.class);

        //execute query and get result list
        List<Role> roles = theQuery.getResultList();

        //return the results
        return roles;
	}

}
