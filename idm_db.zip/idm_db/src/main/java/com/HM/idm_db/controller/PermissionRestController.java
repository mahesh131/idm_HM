package com.HM.idm_db.controller;
import com.HM.idm_db.entities.Permission;
import com.HM.idm_db.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import java.util.List;

@RestController
@RequestMapping("/api")
public class PermissionRestController
{
    private PermissionService permissionService;

    @Autowired
    public PermissionRestController(PermissionService  thePermissionService)
    {
        permissionService = thePermissionService;
    }
    @GetMapping("/permissions")
    public List<Permission> findAll()
    {
        return permissionService.findAll();
    }

}
