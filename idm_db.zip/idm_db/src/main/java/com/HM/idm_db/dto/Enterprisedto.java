package com.HM.idm_db.dto;

import com.HM.idm_db.entities.Enterprise;

import java.util.List;



public interface Enterprisedto 
{
	
	  public List<Enterprise> findAll();
	  
	  
}
