package com.HM.idm_db.dto;

import com.HM.idm_db.entities.Role;

import java.util.List;



public interface Roledto
{
	 public List<Role> findAll();
	   
	
}
