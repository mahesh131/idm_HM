package com.HM.idm_db.controller;

import java.util.List;

import com.HM.idm_db.entities.PasswordPolicy;
import com.HM.idm_db.service.PasswordPolicyService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api")
public class PasswordPolicyRestController 
{
	private PasswordPolicyService passwordPolicyService;
	
	PasswordPolicyRestController(PasswordPolicyService thePasswordPolicyService)
	{
		passwordPolicyService =thePasswordPolicyService;
		
	}
	@GetMapping("/passwordpolicies")
	public List<PasswordPolicy> findAll()
	{
		return passwordPolicyService.findAll();
	}
	
	
	
	
	
	
	
	
	

}
