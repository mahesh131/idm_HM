package com.HM.idm_db.service;

import java.util.List;
import javax.transaction.Transactional;

import com.HM.idm_db.dto.PasswordPolicyHibernateimpl;
import com.HM.idm_db.entities.PasswordPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PasswordPolicyServicehibernateImpl implements PasswordPolicyService {
	
	
	private PasswordPolicyHibernateimpl passwordPolicyHibernateimpl;
	
	@Autowired
	PasswordPolicyServicehibernateImpl(PasswordPolicyHibernateimpl  thePasswordPolicyHibernateimpl)
	{
		passwordPolicyHibernateimpl = thePasswordPolicyHibernateimpl;
	}
	
	
	@Override
	@Transactional
	public List<PasswordPolicy> findAll() {
		
		return passwordPolicyHibernateimpl.findAll();
	}

}
