package com.HM.idm_db.service;

import com.HM.idm_db.entities.Enterprise;

import java.util.List;


public interface EnterpriseService {
	 public List<Enterprise> findAll();

}
