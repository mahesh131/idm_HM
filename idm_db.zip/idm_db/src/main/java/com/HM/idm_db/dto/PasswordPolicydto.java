package com.HM.idm_db.dto;

import com.HM.idm_db.entities.PasswordPolicy;

import java.util.List;



public interface PasswordPolicydto {
	
	public List<PasswordPolicy> findAll();

}
