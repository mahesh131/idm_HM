package com.HM.idm_db.dto;



import com.HM.idm_db.entities.Permission;

import java.util.List;

public interface Permissiondto {
    public List<Permission> findAll();
    public Permission findByFeature(int feature);
}
