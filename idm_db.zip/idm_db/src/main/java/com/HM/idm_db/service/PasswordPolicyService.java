package com.HM.idm_db.service;

import com.HM.idm_db.entities.PasswordPolicy;

import java.util.List;



public interface PasswordPolicyService 
{
	public List<PasswordPolicy> findAll();

}
