package com.HM.idm_db.dto;

import java.util.List;

import javax.persistence.EntityManager;

import com.HM.idm_db.entities.PasswordPolicy;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class PasswordPolicyHibernateimpl implements PasswordPolicydto {
 private EntityManager entitymanager;
 
 @Autowired
public PasswordPolicyHibernateimpl(EntityManager theEntitymanager)
{
	 entitymanager = theEntitymanager;
}
 
	@Override
	public List<PasswordPolicy> findAll() {
   Session		 currentSession = entitymanager.unwrap(Session.class);
   Query<PasswordPolicy> theQuery = currentSession.createQuery("from PasswordPolicy",PasswordPolicy.class);
   List<PasswordPolicy> allPasswordPolicy = theQuery.getResultList();
		return allPasswordPolicy;
	}

}
