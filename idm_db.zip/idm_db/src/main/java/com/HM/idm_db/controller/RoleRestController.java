package com.HM.idm_db.controller;

import java.util.List;

import com.HM.idm_db.entities.Role;
import com.HM.idm_db.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api")
public class RoleRestController 
{
	
	private RoleService roleService;
	
	@Autowired
	public RoleRestController(RoleService theRoleService)
	{
		roleService =  theRoleService;
	}
    
	@GetMapping("/roles")
	public List<Role> findAllRoles()
	{
		return roleService.findAll();
	}
	
	
}
