package com.HM.idm_db.dto;

import com.HM.idm_db.entities.User;

import java.util.List;



public interface Userdto 
{
 public List<User> findAll();
 
}
