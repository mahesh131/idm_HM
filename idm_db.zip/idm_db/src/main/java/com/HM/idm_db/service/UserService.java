package com.HM.idm_db.service;

import com.HM.idm_db.entities.User;

import java.util.List;



public interface UserService 
{
public List<User> findAll();
}
