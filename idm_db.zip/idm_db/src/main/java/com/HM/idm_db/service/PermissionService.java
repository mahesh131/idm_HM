package com.HM.idm_db.service;



import com.HM.idm_db.entities.Permission;

import java.util.List;

public interface PermissionService {

    public List<Permission> findAll();

    public Permission findByFeature(int feature);

}
