package com.HM.idm_db.service;

import java.util.List;

import javax.transaction.Transactional;

import com.HM.idm_db.dto.UserdtoHibernateImpl;
import com.HM.idm_db.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceHibernateImpl implements UserService
{
	private UserdtoHibernateImpl userdtoHibernateImpl;
	@Autowired
public UserServiceHibernateImpl (UserdtoHibernateImpl theUserdtoHibernateImpl )
{
	userdtoHibernateImpl =theUserdtoHibernateImpl ;
}
	@Override
	@Transactional
	public List<User> findAll()
	{
	
		return userdtoHibernateImpl.findAll();
	}

}
