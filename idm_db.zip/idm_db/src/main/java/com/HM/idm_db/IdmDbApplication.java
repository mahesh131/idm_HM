package com.HM.idm_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdmDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdmDbApplication.class, args);
	}

}
